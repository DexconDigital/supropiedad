const TOKEN = '8uyOx0ieVEsNqAS2KQNesUNJMSF7wCT08DAT3fGS-813';
var URLDOMAIN = window.origin+'/supropiedad/';

console.log(window.location);
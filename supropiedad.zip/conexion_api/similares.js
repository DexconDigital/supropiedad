// const ARRIENDO = 'Arriendo';
// const ARRIENDO_VENTA ="Arriendo/venta";
// var ramdon = Math.floor((Math.random() * 10) + 1);

// $.ajax({
//     url: 'http://www.simi-api.com/ApiSimiweb/response/v2.1.3/filtroInmueble/limite/0/total/3/departamento/0/ciudad/0/zona/0/barrio/0/tipoInm/0/tipOper/0/areamin/0/areamax/0/valmin/0/valmax/0/campo/0/order/0/banios/0/alcobas/0/garajes/0/sede/0/usuario/0',
//     type: 'GET',
//     beforeSend: function (xhr) {
//     xhr.setRequestHeader(
//         'Authorization',
//         'Basic ' + btoa('Authorization:'+TOKEN));
//     },
//     'dataType': "json",
//     success:function(data)
//     {   
//         var similares = data.Inmuebles;
//         // console.log(similares);
//         propiedades_similares(similares);
//         // console.log(propiedad_similar);
//         // $("#p_similares").append(propiedad_similar);
//     }             
//    });

<?php 
    $url_host = 'http://'.$_SERVER["HTTP_HOST"].'/supropiedad/';
    // $url_host = 'https://'.$_SERVER["HTTP_HOST"].'/';
    $url_total = 'http://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

    define('TOKEN', '8uyOx0ieVEsNqAS2KQNesUNJMSF7wCT08DAT3fGS-813');

?>
if(pagina == 'inmuebles'){
    $('#button_avanzada').click(()=>{
        $('.busqueda_avanzada').addClass('d-none');
    });
    $('#button_avanzada_2').click(()=>{
        $('.busqueda_avanzada').removeClass('d-none');
    });

}
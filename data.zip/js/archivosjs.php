<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="<?php echo $url_host?>js/common.js"></script>
<script src="<?php echo $url_host?>js/menu.js"></script>
<script src="<?php echo $url_host?>js/owl.carousel.min.js"></script>
<script src="<?php echo $url_host?>js/jquery.prettyPhoto.js"></script>
<script src="<?php echo $url_host?>js/variables.js"></script>
<script src="<?php echo $url_host?>js/top.js"></script>
<script src="<?php echo $url_host?>js/tabs.js"></script>
<script src="<?php echo $url_host?>js/scripts.js"></script>
<script type="text/javascript" src="<?php echo $url_host?>rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="<?php echo $url_host?>rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

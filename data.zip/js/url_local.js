const URL_LOCAL="http://localhost/maxibienes/public_html/";

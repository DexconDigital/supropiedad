//List of agencies
var agencies = [
	{
		"id": 0,
		"title": "Agency 1",
		"latitude":40.7679771,
		"longitude":-73.9622927,
		"image":"images/agency3.jpg",
		"description":"242 E 67th St, New York, NY <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	},
	{
		"id": 1,
		"title": "Agency 2",
		"latitude":34.058356,
		"longitude":-118.263621,
		"image":"images/agency2.jpg",
		"description":"S Lucas Ave, Los Angeles, CA <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	},
	{
		"id": 2,
		"title": "Agency 3",
		"latitude":40.696727,
		"longitude":-73.995323,
		"image":"images/agency6.jpg",
		"description":"162 Hicks St Brooklyn, NY <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	},
	{
		"id": 3,
		"title": "Agency 4",
		"latitude":40.724903,
		"longitude":-73.978197,
		"image":"images/agency1.jpg",
		"description":"133 Avenue C, New York, NY <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	},
	{
		"id": 4,
		"title": "Agency 5",
		"latitude":26.823482,
		"longitude": -80.113168,
		"image":"images/agency4.jpg",
		"description":"Palm Beach Gardens, FL <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	},
	{
		"id": 5,
		"title": "Agency 6",
		"latitude":26.727440,
		"longitude":-80.051421,
		"image":"images/agency3.jpg",
		"description":"West Palm Beach, FL <br> Phone: (123) 546-7890",
		"link":"agency-detail.html",
		"map_marker_icon":"images/markers/coral-marker-cozy.png"
	}
];
<?php

function Conect()
{
    $echo = mysqli_connect("localhost","root","","maxibienes");
    return $echo;
}


// function Conect()
// {
//     $echo = mysqli_connect("localhost","maxibienes","maxibienes","maxibienes");
//     return $echo;
// }


?>

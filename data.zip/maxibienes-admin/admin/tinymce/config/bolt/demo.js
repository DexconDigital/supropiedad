configure({
  configs: [
    './prod.js'
  ]
})

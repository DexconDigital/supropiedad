configure({
  configs: [
    '../../../../config/bolt/prod.js'
  ]
});

<?php

// function Conect()
// {
//     # code...

//     $echo = mysqli_connect("localhost","root","","maxibienes");

//     return $echo;
// }

function Conect()
{
    $echo = mysqli_connect("localhost","root","","maxibienes");
    return $echo;
}



?>
